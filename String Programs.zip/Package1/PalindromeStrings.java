package Package1;

import java.util.Scanner;

public class PalindromeStrings {

	public static void main(String[] args) {
		
		
		System.out.print("Enter String : ");
		Scanner sc = new Scanner(System.in);
		String original=sc.next();
		
		String reverse="";
		
		for (int i=original.length()-1 ; i>=0 ;--i)
			
		{
			reverse=reverse +original.charAt(i);
		}
		
		
		if (original.equals(reverse))
		{
			System.out.println("String is plaindrome");
		}
		else
		{
			System.out.println("String is not palindrome");
		}
		
	}

}
