package Package1;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class CharacterCount {

	public static void main(String[] args) {
		
		
		System.out.print("enter string : ");
		
		Scanner sc = new Scanner(System.in);
		String s1 = sc.next();

		Charcount(s1);
		
	}

	/**
	 * @param str1
	 */
	private static void Charcount(String str1) {
	
		
		char[] chararr = str1.toLowerCase().toCharArray();
		
		HashMap<Character,Integer> hm = new HashMap<Character,Integer>();
		
		for (char ch : chararr)
			if(hm.containsKey(ch))
			{
				hm.put(ch, hm.get(ch)+1);
			}
			else
			{
				hm.put(ch, 1);
			}
		
		
		Set<Character>  allkeys = hm.keySet();
		 
		for (char ch :allkeys) {
			if (hm.get(ch)>1)
				System.out.println("Character: " + ch+ " , " + "Count : " + hm.get(ch));
		}
		
		
	}
	
	
	

}
