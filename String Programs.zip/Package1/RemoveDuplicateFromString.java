package Package1;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class RemoveDuplicateFromString {

	public static void main(String[] args) {
	System.out.print("Enter String : ");
	Scanner sc = new Scanner(System.in);
	String s1=sc.next();
	DuplicateString( s1);
	}
	
	public static void DuplicateString(String str)
	{
		
		Character c=null;
		Set<Character> charset = new LinkedHashSet<Character>();
		
		for (int i=0; i<str.length(); i++)
		{
			c=str.charAt(i);		
		    charset.add(c); 
		}
	
	StringBuffer sb = new StringBuffer();
	
	for (Character ch:charset)
	{
		sb.append(ch);
		
	}
      	System.out.println("Output : "+sb);
	
}
}
