package Package1;

import java.util.Arrays;
import java.util.Scanner;

public class CheckAnagram {

	public static void main(String[] args) {
		
		System.out.print("enter first string : ");
		Scanner sc = new Scanner(System.in);
		String s1= sc.nextLine();
		
		System.out.print("enter second  string : ");
		String s2= sc.nextLine();
		
		boolean status =CheckAnagramofstring(s1,s2);
		
		if (status)
			System.out.println("strings are anagram");
		else
			System.out.println("strings are not anagram");
		sc.close();
	}

	public static boolean CheckAnagramofstring(String str1, String str2) {
		
		
		if (str1.length() != str2.length())
		{
			return false;
		
			
		}
		
		
		char[] a=str1.toCharArray();
		char[] b =str2.toCharArray();
		
		Arrays.sort(a);
		Arrays.sort(b);
		
		if (Arrays.equals(a, b))
		{
			return true;
		}
		
		else
		{
			return false;
		}
		
		
	}

	

}
