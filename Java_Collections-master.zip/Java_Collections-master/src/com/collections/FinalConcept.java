package com.collections;

public class FinalConcept
{
	public static void main(String[] args) {
		
		//final keyword is used to define Constant values, Means we can not change the value
		// To prevent inheritance
		// To prevent Method overriding
		
		
	}
	

}
