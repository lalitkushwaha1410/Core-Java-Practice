package com.collections;

public class Employee 
{
	
	String name;
	int age;
	String dept;
	
	Employee(String name, int age, String dept)
	{
		this.name=name;
		this.age=age;
		this.dept=dept;
		
   //Here why i am using "this" keyword here my Global variables and local Variables are same, Thta's why
		
	}
	
	

}
